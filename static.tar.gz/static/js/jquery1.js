$(document).ready(function(){
alert('dfsa');
});